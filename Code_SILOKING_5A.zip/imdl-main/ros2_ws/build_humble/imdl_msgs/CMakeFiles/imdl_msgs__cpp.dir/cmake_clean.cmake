file(REMOVE_RECURSE
  "CMakeFiles/imdl_msgs__cpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object__builder.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object__struct.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object__traits.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object__type_support.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object_array__builder.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object_array__struct.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object_array__traits.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detail/detected_object_array__type_support.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detected_object.hpp"
  "rosidl_generator_cpp/imdl_msgs/msg/detected_object_array.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/imdl_msgs__cpp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
