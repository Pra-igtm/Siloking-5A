# Empty dependencies file for imdl_msgs__rosidl_generator_py.
# This may be replaced when dependencies are built.
