# Empty dependencies file for imdl_msgs__rosidl_typesupport_c.
# This may be replaced when dependencies are built.
