file(REMOVE_RECURSE
  "CMakeFiles/imdl_msgs"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/imdl_msgs.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
