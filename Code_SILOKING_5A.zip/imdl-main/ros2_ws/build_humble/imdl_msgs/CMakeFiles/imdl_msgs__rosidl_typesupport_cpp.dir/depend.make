# Empty dependencies file for imdl_msgs__rosidl_typesupport_cpp.
# This may be replaced when dependencies are built.
